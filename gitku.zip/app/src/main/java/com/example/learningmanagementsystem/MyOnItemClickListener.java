package com.example.learningmanagementsystem;

import android.view.View;
/**
 * item点击接口
 */
public interface MyOnItemClickListener {
    void OnItemClickListener(View view, int position);
}
